package com.hie2j.listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

public class WordAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Word> studentArrayList;
    private IOnDataChangeListener listener;
    private int type;

    public WordAdapter(Context context, ArrayList<Word> studentArrayList, WordFragment wordFragment, int i) {
        this.context = context;
        this.studentArrayList = studentArrayList;
        this.listener = wordFragment;
        type = i;
    }

    @Override
    public int getCount() {
        return studentArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return studentArrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(
                    R.layout.stu_item, viewGroup, false);

            WordViewHolder viewHolder = new WordViewHolder();
            viewHolder.tvStuno = view.findViewById(R.id.txt_stuno);
            viewHolder.tvName = view.findViewById(R.id.txt_name);
            viewHolder.ivDel = view.findViewById(R.id.iv_del);
            viewHolder.tvAge = view.findViewById(R.id.txt_age);


            view.setTag(viewHolder);
        }

        final Word student = studentArrayList.get(i);

        WordViewHolder viewHolder = (WordViewHolder) view.getTag();
        viewHolder.tvStuno.setText(student.getWord());
        if (type == 2) {
            viewHolder.tvName.setText(student.getMeaning());
            viewHolder.tvAge.setText(student.getSample());
        } else {
            viewHolder.tvName.setVisibility(View.GONE);
            viewHolder.tvAge.setVisibility(View.GONE);

        }

        viewHolder.ivDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 不要在这里进行数据库操作
                listener.del(student);
            }
        });

        return view;
    }
}
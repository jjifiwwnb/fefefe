package com.hie2j.listview;

public interface IOnDataChangeListener {
    void del(Word student);
}

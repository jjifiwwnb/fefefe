package com.hie2j.listview;

import android.widget.ImageView;
import android.widget.TextView;

public class WordViewHolder {
    TextView tvStuno;
    TextView tvName;
    TextView tvAge;
    ImageView ivDel;
}

package com.hie2j.listview;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Activity_add extends AppCompatActivity {
    private EditText edtStuno;
    private EditText edtName;
    private EditText edt_liju;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        edtStuno = findViewById(R.id.edt_stuno);
        edtName = findViewById(R.id.edt_name);
        edt_liju = findViewById(R.id.edt_liju);
        btnSave = findViewById(R.id.btn_save);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String stuno = edtStuno.getText().toString();
                String name = edtName.getText().toString();
                String liju = edt_liju.getText().toString();

                Intent intent = new Intent();
                Word student = new Word(stuno,name,liju);
                intent.putExtra("WORD",student);
//                intent.putExtra("STUNO", stuno);
//                intent.putExtra("NAME", name);
//                intent.putExtra("AGE", age);

                setResult(2001, intent);
                finish();
            }
        });
    }
}

package com.hie2j.listview;

import java.io.Serializable;

public class Word implements Serializable {
    private String word;
    private String meaning;
    private String sample;

    public String getWord() {
        return word;
    }

    public String getMeaning() {
        return meaning;
    }

    public String getSample() {
        return sample;
    }

    public Word(String word, String meaning, String sample) {
        this.word = word;
        this.meaning = meaning;
        this.sample = sample;
    }
}


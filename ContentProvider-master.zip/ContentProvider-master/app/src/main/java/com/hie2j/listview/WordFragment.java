package com.hie2j.listview;

import android.app.Fragment;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class WordFragment extends Fragment implements IOnDataChangeListener {
    private EditText edtKey;
    private ImageView ivSearch;
    private ListView lvStu;
    private WebView webview;
    private Button btnAdd;
    private ArrayList<Word> studentArrayList = new ArrayList<>();
    private WordAdapter adapter;
    private WordOpenHelper mWordOpenHelper;
    View view;
    private int type = 1;
    EditText edt_stuno;
    EditText edt_name;
    EditText edtLiju;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_word, container, false);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        findViews();
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            adapter = new WordAdapter(getContext(), studentArrayList, this, 2);
        } else {
            adapter = new WordAdapter(getContext(), studentArrayList, this, 1);
        }

        readDataFromDB();

        lvStu.setAdapter(adapter);
        lvStu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Word student = studentArrayList.get(i);
                tipDialog(student);
            }
        });

        lvStu.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                String strURL = "http://dict.youdao.com/m/search?keyfrom=dict.mindex&q=" + studentArrayList.get(i).getWord();//加载路径
                Uri uri = Uri.parse(strURL);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
//                webview.setVisibility(View.VISIBLE);
//                lvStu.setVisibility(View.GONE);
//                webview.loadUrl(strURL);//加载到WebView控件上显示
//                webview.setWebViewClient(new WebViewClient() {//禁止调用系统浏览器
//                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
//                        view.loadUrl(url);
//                        return false;
//                    }
//                });

                return true;
            }
        });
    }

    private void findViews() {
        lvStu = view.findViewById(R.id.lv_stu);
        webview = view.findViewById(R.id.webview);
        btnAdd = view.findViewById(R.id.btn_add);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                webview.setVisibility(View.GONE);
                lvStu.setVisibility(View.VISIBLE);
                Intent intent = new Intent();
                intent.setClass(getContext(), Activity_add.class);
                startActivityForResult(intent, 1001);
            }
        });

        edtKey = view.findViewById(R.id.edt_key);
        ivSearch = view.findViewById(R.id.iv_search);
        ivSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String key = edtKey.getText().toString();
                Uri uri = Uri.parse("content://com.hie.word/words");
                String where = "word like '%" + key + "%' OR meaning like '%" + key + "%' " +
                        "OR sample = '" + key + "'";
                studentArrayList.clear();
                Cursor cursor = getActivity().getContentResolver().query(uri, null, where, null, null);
                if (cursor != null && cursor.getCount() > 0) {
                    for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                        String stuno = cursor.getString(0);
                        String name = cursor.getString(1);
                        String liju = cursor.getString(2);

                        Word student = new Word(stuno, name, liju);
                        studentArrayList.add(student);
                    }
                }
                adapter.notifyDataSetChanged();
                cursor.close();
//                searchFromDB(key);
            }
        });
        lvStu.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                return true;
            }
        });
        edtKey.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String key = edtKey.getText().toString();
                Uri uri = Uri.parse("content://com.hie.word/words");
                String where = "word like '%" + key + "%' OR meaning like '%" + key + "%' " +
                        "OR sample = '" + key + "'";
                studentArrayList.clear();
                Cursor cursor = getActivity().getContentResolver().query(uri, null, where, null, null);
                if (cursor != null && cursor.getCount() > 0) {
                    for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                        String stuno = cursor.getString(0);
                        String name = cursor.getString(1);
                        String liju = cursor.getString(2);
                        Word student = new Word(stuno, name, liju);
                        studentArrayList.add(student);
                    }
                }
                adapter.notifyDataSetChanged();
                cursor.close();
//                searchFromDB(key);
            }
        });
    }


    /**
     * 从数据库读取单词列表
     * 使用ContentProvider
     */
    private void readDataFromDB() {
        Uri uri = Uri.parse("content://com.hie.word/words");
        Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
        studentArrayList.clear();
        if (cursor != null && cursor.getCount() > 0) {
            for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                String stuno = cursor.getString(0);
                String name = cursor.getString(1);
                String liju = cursor.getString(2);

                Word student = new Word(stuno, name, liju);
                studentArrayList.add(student);
            }
        }
        adapter.notifyDataSetChanged();
        cursor.close();
    }

    @Override
    public void del(Word student) {
        Uri uri = Uri.parse("content://com.hie.word/words");
        String where = "word = '" + student.getWord() + "'";
        int rows = getActivity().getContentResolver().delete(uri, where, null);
        Toast.makeText(getContext(), "删除了" + rows + "行", Toast.LENGTH_SHORT).show();
        readDataFromDB();
    }

    public void tipDialog(final Word student) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = View.inflate(getActivity(), R.layout.activity_edit, null);
        edt_stuno = view.findViewById(R.id.edt_stuno);
        edt_name = view.findViewById(R.id.edt_name);
        edtLiju = view.findViewById(R.id.edt_liju);
        edtLiju.setText(student.getSample());
        edt_name.setText(student.getMeaning());
        edt_stuno.setText(student.getWord());
        builder.setView(view);
        builder.setCancelable(true);            //点击对话框以外的区域是否让对话框消失

        //设置正面按钮
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Uri uri = Uri.parse("content://com.hie.word/words");
                ContentValues values = new ContentValues();
                values.put("word", edt_stuno.getText().toString());
                values.put("meaning", edt_name.getText().toString());
                values.put("sample", edtLiju.getText().toString());
                String where = "word = '" + student.getWord() + "'";
                int rows = getActivity().getContentResolver().update(uri, values, where, null);
                Toast.makeText(getContext(), "更新了" + rows + "行", Toast.LENGTH_SHORT).show();
                readDataFromDB();

                dialog.dismiss();
            }
        });
        //设置反面按钮
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getContext(), "你点击了取消", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        builder.show();                              //显示对话框
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == 2001) {
            Uri uri = Uri.parse("content://com.hie.word/words");
            Word student = (Word) data.getSerializableExtra("WORD");
//            String stuno = data.getStringExtra("STUNO");
//            String name = data.getStringExtra("NAME");
//            int age = data.getIntExtra("AGE", 0);
//
//            Student student =  new Student(stuno, name, age);
            ContentValues values = new ContentValues();
            values.put("word", student.getWord());
            values.put("meaning", student.getMeaning());
            values.put("sample", student.getSample());
            getActivity().getContentResolver().insert(uri, values);
            readDataFromDB();
//            addStudentToDB(student);
        } else if (resultCode == 3001) {
            Uri uri = Uri.parse("content://com.hie.word/words");
            Word student = (Word) data.getSerializableExtra("WORD");
//            String stuno = data.getStringExtra("STUNO");
//            String name = data.getStringExtra("NAME");
//            int age = data.getIntExtra("AGE", 0);
//
//            Student student =  new Student(stuno, name, age);

            ContentValues values = new ContentValues();
            values.put("word", student.getWord());
            values.put("meaning", student.getMeaning());
            values.put("sample", student.getSample());
            String where = "word = '" + student.getWord() + "'";
            int rows = getActivity().getContentResolver().update(uri, values, where, null);
            Toast.makeText(getContext(), "更新了" + rows + "行", Toast.LENGTH_SHORT).show();
//            updateStudentToDB(student);
            readDataFromDB();
        }
    }

}
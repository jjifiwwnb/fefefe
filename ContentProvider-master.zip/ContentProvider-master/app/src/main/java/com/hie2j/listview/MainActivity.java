package com.hie2j.listview;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements IOnDataChangeListener {
    private EditText edtKey;
    private ImageView ivSearch;
    private ListView lvStu;
    private Button btnAdd;
    private ArrayList<Word> studentArrayList = new ArrayList<>();
    private WordAdapter adapter;
    private WordOpenHelper mWordOpenHelper;


    FrameLayout wordContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wordContent = findViewById(R.id.wordContent);
        WordFragment wordFragment = new WordFragment();
        getFragmentManager().beginTransaction().replace(R.id.wordContent, wordFragment).commit();

    }

    //初始化单词列表
    private void initStudentArrayList() {
        studentArrayList.add(new Word("17001", "lisa", "this is"));
        studentArrayList.add(new Word("17002", "lier", "this is"));
        studentArrayList.add(new Word("17003", "liwu", "this is"));
        studentArrayList.add(new Word("17004", "liqi", "this is"));
    }

    private void findViews() {
        lvStu = findViewById(R.id.lv_stu);
        btnAdd = findViewById(R.id.btn_add);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, Activity_add.class);
                startActivityForResult(intent, 1001);
            }
        });

        edtKey = findViewById(R.id.edt_key);
        ivSearch = findViewById(R.id.iv_search);
        ivSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String key = edtKey.getText().toString();
                Uri uri = Uri.parse("content://com.hie.word/words");
                String where = "word like '%" + key + "%' OR meaning like '%" + key + "%' " +
                        "OR sample = '" + key + "'";
                studentArrayList.clear();
                Cursor cursor = getContentResolver().query(uri, null, where, null, null);
                if (cursor != null && cursor.getCount() > 0) {
                    for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                        String stuno = cursor.getString(0);
                        String name = cursor.getString(1);
                        String liju = cursor.getString(2);

                        Word student = new Word(stuno, name, liju);
                        studentArrayList.add(student);
                    }
                }
                adapter.notifyDataSetChanged();
                cursor.close();
//                searchFromDB(key);
            }
        });
        lvStu.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                return true;
            }
        });
        edtKey.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String key = edtKey.getText().toString();
                Uri uri = Uri.parse("content://com.hie.word/words");
                String where = "word like '%" + key + "%' OR meaning like '%" + key + "%' " +
                        "OR sample = '" + key + "'";
                studentArrayList.clear();
                Cursor cursor = getContentResolver().query(uri, null, where, null, null);
                if (cursor != null && cursor.getCount() > 0) {
                    for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                        String stuno = cursor.getString(0);
                        String name = cursor.getString(1);
                        String liju = cursor.getString(2);
                        Word student = new Word(stuno, name, liju);
                        studentArrayList.add(student);
                    }
                }
                adapter.notifyDataSetChanged();
                cursor.close();
//                searchFromDB(key);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == 2001) {
            Uri uri = Uri.parse("content://com.hie.word/words");
            Word student = (Word) data.getSerializableExtra("WORD");
//            String stuno = data.getStringExtra("STUNO");
//            String name = data.getStringExtra("NAME");
//            int age = data.getIntExtra("AGE", 0);
//
//            Student student =  new Student(stuno, name, age);
            ContentValues values = new ContentValues();
            values.put("word", student.getWord());
            values.put("meaning", student.getMeaning());
            values.put("sample", student.getSample());
            getContentResolver().insert(uri, values);
            readDataFromDB();
//            addStudentToDB(student);
        } else if (resultCode == 3001) {
            Uri uri = Uri.parse("content://com.hie.word/words");
            Word student = (Word) data.getSerializableExtra("WORD");
//            String stuno = data.getStringExtra("STUNO");
//            String name = data.getStringExtra("NAME");
//            int age = data.getIntExtra("AGE", 0);
//
//            Student student =  new Student(stuno, name, age);

            ContentValues values = new ContentValues();
            values.put("word", student.getWord());
            values.put("meaning", student.getMeaning());
            values.put("sample", student.getSample());
            String where = "word = '" + student.getWord() + "'";
            int rows = getContentResolver().update(uri, values, where, null);
            Toast.makeText(MainActivity.this, "更新了" + rows + "行", Toast.LENGTH_SHORT).show();
//            updateStudentToDB(student);
            readDataFromDB();
        }
    }

    //m没有封装的update
    private void updateStudentToDB(Word student) {
        SQLiteDatabase db = mWordOpenHelper.getWritableDatabase();

        /** 第一种 组装语句
         String sql = "update student set name = '"+student.getName()+"'," +
         " age = "+student.getAge()+" where stuno = '"+student.getStuno()+"'";
         db.execSQL(sql);
         db.close();
         readDataFromDB();*/

        // 第二种方式 update
        ContentValues values = new ContentValues();
        values.put("word", student.getWord());
        String where = "word = '" + student.getWord() + "'";
        db.update("words", values, where, null);
        db.close();
        readDataFromDB();

    }


    @Override
    public void del(Word student) {

        Uri uri = Uri.parse("content://com.hie.word/words");
        String where = "word = '" + student.getWord() + "'";
        int rows = getContentResolver().delete(uri, where, null);
        Toast.makeText(MainActivity.this, "删除了" + rows + "行", Toast.LENGTH_SHORT).show();


//        SQLiteDatabase db = studbOpenHelper.getWritableDatabase();
       /* 删除也有两种 一种是execSql()
       String sql = "delete from student where stuno = '"+student.getStuno()+"'";
       db.execSQL(sql);
       db.close();
       readDataFromDB();
       */

       /* 第二种是使用delete接口
        String where = "stuno = '" + student.getStuno() + "'";
        db.delete("student", where, null);
        db.close();
        readDataFromDB();*/

         /*第三种是使用delete接口
        String where = "stuno = ?";
        String[] argArray = {student.getStuno()};
        db.delete("student", where, argArray);
        db.close();*/
        readDataFromDB();
    }

    /**
     * 从数据库读取单词列表
     * 使用ContentProvider
     */
    private void readDataFromDB() {
        Uri uri = Uri.parse("content://com.hie.word/words");
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        studentArrayList.clear();
        if (cursor != null && cursor.getCount() > 0) {
            for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                String stuno = cursor.getString(0);
                String name = cursor.getString(1);
                String liju = cursor.getString(1);

                Word student = new Word(stuno, name, liju);
                studentArrayList.add(student);
            }
        }
        adapter.notifyDataSetChanged();
        cursor.close();
    }


}
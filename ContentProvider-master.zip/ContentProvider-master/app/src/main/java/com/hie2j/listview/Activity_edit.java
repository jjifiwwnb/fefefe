package com.hie2j.listview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity_edit extends AppCompatActivity {
    private EditText edtStuno;
    private EditText edtName;
    private EditText edt_liju;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        edtStuno = findViewById(R.id.edt_stuno);
        edtName = findViewById(R.id.edt_name);
        edt_liju = findViewById(R.id.edt_liju);
        btnSave = findViewById(R.id.btn_save);

        Word student = (Word) getIntent().getSerializableExtra("WORD");
        if (student == null) {
            Toast.makeText(Activity_edit.this, "word == null", Toast.LENGTH_SHORT).show();
        } else {
            edtStuno.setText(student.getWord());
            edtName.setText(student.getWord());
            edt_liju.setText(student.getMeaning());
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String stuno = edtStuno.getText().toString();
                String name = edtName.getText().toString();
                String liju = edt_liju.getText().toString();

                Word student = new Word(stuno, name, liju);
                Intent intent = new Intent();
                intent.putExtra("WORD", student);
                setResult(3001, intent);
                finish();
            }
        });

    }
}